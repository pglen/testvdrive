# Python test drive utility

## A nifty utility to test things.

 The test case file drives a send / expect engine. The expect is then evaluated and
the result is printed in a green colored 'OK' or a red colored 'ERR'.

    ./testvdrive.py testcase.txt

If you installed from pip, use:

    testvdrive testcase.txt

The test case file contains the test instructions, one line per test. The format:

    #   Context_string  Send_string     Expect_string   Find/Compare
    #   --------------  -----------     -------------   ------------
    #    for the user   what to test    what to expect  True if Find


### Example test cases:

    [ "Echo Command", "", "", True],                # NOOP
    [ "Test ls", "ls", "Make", True],               # Do we have a Make file
    [ "DF command", "df", "blocks", "regex" ],      # Search regex
    [ "DF mregex", "df", ".*blo",  "mregex" ],      # Match regex

### The output of example test cases (colored in terminal):

    Echo Command     	 OK
    Test ls          	 OK
    DF command       	 OK
    DF mregex        	 OK

// EOF
